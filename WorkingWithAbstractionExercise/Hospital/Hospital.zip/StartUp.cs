﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Hospital
{
    class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
