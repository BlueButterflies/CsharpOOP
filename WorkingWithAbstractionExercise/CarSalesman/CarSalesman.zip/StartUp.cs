﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CarSalesman
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Runner runner = new Runner();
            runner.Run();
        }
    }
}
