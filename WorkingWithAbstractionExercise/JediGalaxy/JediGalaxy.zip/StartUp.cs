﻿using System;
using System.Linq;

namespace JediGalaxy
{
    class StartUp
    {
        static void Main(string[] args)
        {
            InputInfo.Info();
        }
    }
}
