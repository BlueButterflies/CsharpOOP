﻿using System;
using System.Linq;

namespace Sneaking
{
    class Program
    {
        
        static void Main()
        {
            Runner runner = new Runner();
            runner.Run();
        }
    }
}
