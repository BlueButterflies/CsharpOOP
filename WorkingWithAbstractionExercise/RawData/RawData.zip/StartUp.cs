﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RawData
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            InfoParameters output = new InfoParameters();
            output.Info();
        }
    }
}
