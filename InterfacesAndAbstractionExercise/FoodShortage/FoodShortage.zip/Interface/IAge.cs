﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    public interface IAge
    {
        int Age { get; }
    }
}
