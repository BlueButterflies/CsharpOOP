﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage.Interface
{
    public interface IBirthday
    {
        string Date { get; }
    }
}
