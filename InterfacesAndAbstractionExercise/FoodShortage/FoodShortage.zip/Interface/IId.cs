﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage.Interface
{
    public interface IId
    {
        string Id { get; }
    }
}
