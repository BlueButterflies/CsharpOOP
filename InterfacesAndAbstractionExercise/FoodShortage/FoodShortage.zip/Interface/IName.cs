﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    public interface IName
    {
        string Name { get; }
    }
}
